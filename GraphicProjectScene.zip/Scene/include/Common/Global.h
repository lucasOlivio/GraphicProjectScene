#pragma once
#ifdef NDEBUG
#define DEBUG 0
#else
#define DEBUG 1
#endif