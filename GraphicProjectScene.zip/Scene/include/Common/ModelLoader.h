#pragma once

#include <string>

#include "Component/ModelInfo.h"

bool LoadData(std::string fileName, ModelDrawInfo* pDrawInfo);